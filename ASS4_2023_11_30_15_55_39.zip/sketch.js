// I'm struggling with for/while loops. Everything i do new to this it just explodes and the new stuff overlaps on my old stuff making it just nonexistant. I wanted to make a grid on the "paper" like bullet journals have, but when i'd give it a grid you wouldnt be able to draw on it anymore. 


let penSize = 1;
let penState = 0;
let gridSize = 20;


function setup() {
  createCanvas(600, 400);
  background(232,230,219);


}

function draw() {
  if (mouseIsPressed) {
    if (penState == 0) {
	       line(mouseX, mouseY, pmouseX, pmouseY);
    } 
    
    if (penState == 1) {
	    ellipse(mouseX, mouseY, 10, 10);
    }
    
    if (penState == 2) {
      line(mouseX-5, mouseY-5, mouseX+5, mouseY+5);
      line(mouseX+5, mouseY-5, mouseX-5, mouseY+5);
    }
  }
}

// Clearing
function keyTyped() {
  if (key == 'c') {
    background(232,230,219);
  }


}

// SMALLEr
function keyPressed() {
	if (keyCode == LEFT_ARROW && penSize > 1) {
    penSize -= 1;
  }
// BIGGER :D
  if (keyCode == RIGHT_ARROW) {
		penSize += 1;
  }
    
  strokeWeight(penSize);
}
  
