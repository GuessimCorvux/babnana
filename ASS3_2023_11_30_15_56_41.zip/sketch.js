let beeschurgur = 60;
let goldfish = 100;
let ihavetheflueimnevercodingagain = 0;


function setup() {
  createCanvas(600, 400);

  frameRate(beeschurgur);
  

}

function draw() {
  background(220);
// silly lines
colorMode(RGB, 100)
  stroke(goldfish,ihavetheflueimnevercodingagain, ihavetheflueimnevercodingagain)
line(mouseX,ihavetheflueimnevercodingagain , mouseX, 600);
  stroke(ihavetheflueimnevercodingagain,50,50);
line(mouseY, ihavetheflueimnevercodingagain , mouseY, 400);
  ////////////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
  stroke(ihavetheflueimnevercodingagain, 45,23);
  strokeWeight(5);
  line(mouseX, mouseY, pmouseX, pmouseY);
  
  
  

  

}


