function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(1);
  strokeWeight(2)

  // Stars n shit
noStroke();
fill(200);
quad(10,10,15,15,10,20,5,15)
quad(35,35,40,40,35,45,30,40)
quad(350,350,355,355,350,360,345,355)
quad(100,350, 105, 355, 100, 360, 95, 355)
quad(120,200, 125, 205, 120, 210, 115, 205)
quad(200, 150, 205, 155, 200, 160, 195, 155)
quad(280, 30, 285, 35, 280, 40, 275, 35)
quad(350, 260, 355, 265, 350, 270, 345, 265)
ellipse(200, 100, 12)
ellipse(100,40,5)
ellipse(13,160,10)
ellipse(180,340,10)
ellipse(350,200,5)
ellipse(270,320, 10)
ellipse(250,380,5)
ellipse(300, 130, 5)

  // planets
stroke(1)  
fill(220, 50, 40);
ellipse(230, 234, 120);
fill(140, 112, 20);
ellipse(100, 100, 80);
fill(12,200,12);
ellipse(330,53,20);
 
  // Little alien Fred just wanted some bread, but could'nt because he got hit in the head. *with an astroid :D*
stroke(1);
fill(1,1,1);
ellipse(335, 54, 3)
fill(1,1,1);
ellipse(326, 51, 3)
fill(110,110,120)
  stroke(20,40,10);
ellipse(0,300,200)
  stroke(1);
fill(80)
quad(300, 50, 350, 70, 360, 110, 260, 70)
stroke(100,100,150);
fill(120,120,220, 70)
arc(330, 50, 50, 50, 3.1, 0.8, OPEN) 

  // Swirly Lines 
strokeWeight(2);
stroke(220);
point(285,90);
point(290,115);
point(260, 116)
point(265,140);
strokeWeight(1)
noFill()
beginShape();
curveVertex(285,90);
curveVertex(285,90);
curveVertex(290,115);
curveVertex(260,116);
curveVertex(265,140);
curveVertex(265,140);
endShape();
// 2
strokeWeight(2);
stroke(220);
point(310,100);
point(315,120);
point(300, 124)
point(305,145);
strokeWeight(1)
noFill()
beginShape();
curveVertex(310,100);
curveVertex(310,100);
curveVertex(315,120);
curveVertex(300,124);
curveVertex(305,145);
curveVertex(305,145);
endShape();

  
}
